print("hello world")
print("what up yo")

